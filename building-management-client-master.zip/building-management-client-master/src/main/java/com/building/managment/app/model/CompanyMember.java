package com.building.managment.app.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompanyMember {
    private String MA_NV;
    private String MA_CT;
    private String TEN;
    private String NGAY_SINH;
    private String CMT;
    private String SDT;
}
