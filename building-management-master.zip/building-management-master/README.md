# building-management
no description

#First:
run file console_1.sql
#Second:
fix user, password in file application.properties 